<h1>Consumidor final</h1>
<div class="input-group mb-2 mr-sm-2">
<input type="text" name="nit" placeholder="CF" id="nit" class="form-control" value="CF">
</div>
<div class="input-group mb-2 mr-sm-2">
<input type="text" name="nombre" placeholder="Consumidor Final" class="form-control">
</div>
<div class="input-group mb-2 mr-sm-2">
<input type="text" name="ciudad" placeholder="Guatemala" class="form-control">
</div>